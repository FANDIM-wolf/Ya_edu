import React from 'react'

export default function SettingPage() {
  return (
    <div>SettingPage</div>
  )
}
