

import Book from "./book.svg"
import Home from "./home.svg"
import Improvization from "./improvization.svg"
import Logout from "./logout.svg"
import Repetition from "./repetition.svg"
import Setting from "./setting.svg"
import Teacher from "./teacher.svg"


const images = {
    Book,
    Home,
    Improvization,
    Logout,
    Repetition,
    Setting,
    Teacher
    
}

export default images