import React from 'react'
import MainLayout from '../../layouts/MainLayout'

export default function SettingPage() {
  return (
    <MainLayout></MainLayout>
  )
}
