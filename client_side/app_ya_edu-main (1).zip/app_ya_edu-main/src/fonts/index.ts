import "./ttf/Onest-Black.ttf";
import "./ttf/Onest-Bold.ttf";
import "./ttf/Onest-ExtraBold.ttf";
import "./ttf/Onest-Light.ttf";
import "./ttf/Onest-Medium.ttf";
import "./ttf/Onest-Regular.ttf";
import "./ttf/Onest-Thin.ttf";

import "./ttf/MontserratAlternates-Bold.ttf";
import "./ttf/MontserratAlternates-ExtraBold.ttf";
import "./ttf/MontserratAlternates-ExtraLight.ttf";
import "./ttf/MontserratAlternates-Light.ttf";
import "./ttf/MontserratAlternates-Medium.ttf";
import "./ttf/MontserratAlternates-Regular.ttf";
import "./ttf/MontserratAlternates-SemiBold.ttf";

import "./style.scss";
